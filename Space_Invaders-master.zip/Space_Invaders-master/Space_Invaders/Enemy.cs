﻿namespace Space_Invaders
{

    public class Enemy : Entity
    {
        public enum EnemyType { Normal, Fast, Armored }

        public EnemyType _type;
        public int _points;
        public double _shootChance;

        public Enemy(int health, int speed, int cooldown, int moveOrientation,
                   EnemyType type, int points, double shootChance)
            : base(health, speed, cooldown, moveOrientation)
        {
            _type = type;
            _points = points;
            _shootChance = shootChance;
        }

        public override void Moving() { }
        public override void Die() { }
    }
}