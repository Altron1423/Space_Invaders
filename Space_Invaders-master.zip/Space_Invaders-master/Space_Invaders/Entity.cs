﻿namespace Space_Invaders
{
    public abstract class Entity
    {
        protected int _health;
        protected int _speed;
        protected int _cooldown;
        protected int _moveOrientation;

        public Entity(int health, int speed, int cooldown, int moveOrientation)
        {
            _health = health;
            _speed = speed;
            _cooldown = cooldown;
            _moveOrientation = moveOrientation;
        }

        public abstract void Moving();
        public virtual void TakeDamage(int amount)
        {
            _health -= amount;
            if (_health <= 0)
                Die();
        }
        public abstract void Die();
    }
}
