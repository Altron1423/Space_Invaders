﻿namespace Space_Invaders;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        button1 = new Button();
        player1 = new Player(components);
        player = new Player(components);
        SuspendLayout();
        // 
        // button1
        // 
        button1.Location = new Point(63, 83);
        button1.Margin = new Padding(4, 5, 4, 5);
        button1.Name = "button1";
        button1.Size = new Size(201, 75);
        button1.TabIndex = 0;
        button1.TabStop = false;
        button1.Text = "Say hello";
        button1.UseVisualStyleBackColor = true;
        button1.Click += button1_Click;
        // 
        // player1
        // 
        player1.BorderStyle = BorderStyle.FixedSingle;
        player1.Location = new Point(0, 0);
        player1.Margin = new Padding(4, 5, 4, 5);
        player1.Name = "player1";
        player1.Size = new Size(148, 148);
        player1.TabIndex = 0;
        // 
        // player
        // 
        player.BorderStyle = BorderStyle.FixedSingle;
        player.Location = new Point(441, 561);
        player.Margin = new Padding(6, 8, 6, 8);
        player.Name = "player";
        player.Size = new Size(228, 165);
        player.TabIndex = 1;
        // 
        // Form1
        // 
        AutoScaleDimensions = new SizeF(10F, 25F);
        AutoScaleMode = AutoScaleMode.Font;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        ClientSize = new Size(1127, 743);
        Controls.Add(player);
        Controls.Add(button1);
        Margin = new Padding(4, 5, 4, 5);
        Name = "Form1";
        Text = "Form1";
        Load += Form1_Load;
        KeyDown += player_KeyDown;
        KeyUp += player_KeyUp;
        ResumeLayout(false);
    }

    private Space_Invaders.Player player;

    private Space_Invaders.Player player1;

    private System.Windows.Forms.Button button1;

    #endregion
}