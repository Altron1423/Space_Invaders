﻿namespace Space_Invaders;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        button1 = new Button();
        player1 = new Player(components);
        player = new Player(components);
        button2 = new Button();
        button3 = new Button();
        button4 = new Button();
        button5 = new Button();
        button6 = new Button();
        button7 = new Button();
        SuspendLayout();
        // 
        // button1
        // 
        button1.BackColor = Color.FromArgb(0, 64, 0);
        button1.Font = new Font("Wide Latin", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
        button1.ForeColor = Color.White;
        button1.Location = new Point(239, 240);
        button1.Name = "button1";
        button1.Size = new Size(437, 76);
        button1.TabIndex = 0;
        button1.TabStop = false;
        button1.Text = "НАЖМИ, ЧТОБЫ НАЧАТЬ";
        button1.UseVisualStyleBackColor = false;
        button1.Click += button1_Click;
        button1.MouseLeave += button4_MouseLeave;
        button1.MouseMove += button4_MouseMove;
        // 
        // player1
        // 
        player1.BorderStyle = BorderStyle.FixedSingle;
        player1.Location = new Point(0, 0);
        player1.Margin = new Padding(4, 5, 4, 5);
        player1.Name = "player1";
        player1.Size = new Size(148, 148);
        player1.TabIndex = 0;
        // 
        // player
        // 
        player.BorderStyle = BorderStyle.FixedSingle;
        player.Location = new Point(397, 491);
        player.Margin = new Padding(4, 5, 4, 5);
        player.Name = "player";
        player.Size = new Size(119, 69);
        player.TabIndex = 1;
        player.Visible = false;
        // 
        // button2
        // 
        button2.BackColor = Color.FromArgb(64, 64, 64);
        button2.FlatStyle = FlatStyle.Flat;
        button2.Location = new Point(-7, -5);
        button2.Name = "button2";
        button2.Size = new Size(250, 574);
        button2.TabIndex = 2;
        button2.UseVisualStyleBackColor = false;
        button2.Visible = false;
        // 
        // button3
        // 
        button3.BackColor = Color.FromArgb(64, 64, 64);
        button3.FlatStyle = FlatStyle.Flat;
        button3.Location = new Point(672, -5);
        button3.Name = "button3";
        button3.Size = new Size(250, 574);
        button3.TabIndex = 3;
        button3.UseVisualStyleBackColor = false;
        button3.Visible = false;
        // 
        // button4
        // 
        button4.BackColor = Color.FromArgb(0, 64, 0);
        button4.Font = new Font("Wide Latin", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
        button4.ForeColor = Color.White;
        button4.Location = new Point(12, 12);
        button4.Name = "button4";
        button4.Size = new Size(47, 44);
        button4.TabIndex = 4;
        button4.Text = "||";
        button4.UseVisualStyleBackColor = false;
        button4.Visible = false;
        button4.Click += button4_Click;
        button4.MouseLeave += button4_MouseLeave;
        button4.MouseMove += button4_MouseMove;
        // 
        // button5
        // 
        button5.BackColor = Color.FromArgb(0, 64, 0);
        button5.Font = new Font("Wide Latin", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
        button5.ForeColor = Color.White;
        button5.Location = new Point(339, 195);
        button5.Name = "button5";
        button5.Size = new Size(237, 70);
        button5.TabIndex = 5;
        button5.Text = "ПРОДОЛЖИТЬ";
        button5.UseVisualStyleBackColor = false;
        button5.Visible = false;
        button5.Click += button5_Click;
        button5.MouseLeave += button4_MouseLeave;
        button5.MouseMove += button4_MouseMove;
        // 
        // button6
        // 
        button6.BackColor = Color.FromArgb(0, 64, 0);
        button6.Font = new Font("Wide Latin", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
        button6.ForeColor = Color.White;
        button6.Location = new Point(339, 280);
        button6.Name = "button6";
        button6.Size = new Size(237, 70);
        button6.TabIndex = 6;
        button6.Text = "ВЫХОД";
        button6.UseVisualStyleBackColor = false;
        button6.Visible = false;
        button6.Click += button6_Click;
        button6.MouseLeave += button4_MouseLeave;
        button6.MouseMove += button4_MouseMove;
        // 
        // button7
        // 
        button7.BackColor = Color.Maroon;
        button7.Font = new Font("Wide Latin", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
        button7.ForeColor = Color.White;
        button7.Location = new Point(12, 12);
        button7.Name = "button7";
        button7.Size = new Size(47, 44);
        button7.TabIndex = 7;
        button7.Text = "||";
        button7.UseVisualStyleBackColor = false;
        button7.Visible = false;
        // 
        // Form1
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        BackColor = Color.Black;
        ClientSize = new Size(914, 561);
        Controls.Add(button7);
        Controls.Add(button4);
        Controls.Add(button1);
        Controls.Add(button6);
        Controls.Add(button5);
        Controls.Add(button3);
        Controls.Add(button2);
        Controls.Add(player);
        Name = "Form1";
        Text = "КОСМИЧЕСКИЕ ЗАХВАТЧИКИ";
        Load += Form1_Load;
        KeyDown += player_KeyDown;
        KeyUp += player_KeyUp;
        ResumeLayout(false);
    }

    private Space_Invaders.Player player;

    private Space_Invaders.Player player1;

    private System.Windows.Forms.Button button1;

    #endregion

    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
}