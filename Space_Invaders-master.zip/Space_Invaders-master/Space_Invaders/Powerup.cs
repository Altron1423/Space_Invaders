﻿namespace Space_Invaders
{
    public class Powerup : Projectile
    {
        public enum BonusType { SpeedUp, DoubleShot, Shield, ExtraLife }

        public BonusType _bonus;
        public float _duration;

        public Powerup(int health, int entitySpeed, int cooldown, int moveOrientation,
                     int projectileSpeed, BonusType bonus, float duration)
            : base(health, entitySpeed, cooldown, moveOrientation, projectileSpeed)
        {
            _bonus = bonus;
            _duration = duration;
        }

        public override void Update() { }
        public override bool IsOutOfBounds() { return false; }
        public override bool IntersectsWith(Entity entity) { return false; }
        public override void Moving()
        {
        }
        public override void Die()
        {
        }
    }
}
