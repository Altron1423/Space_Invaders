﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Invaders
{
    public abstract class Projectile : Entity
    {
        protected int _speed;

        public Projectile(int health, int entitySpeed, int cooldown,
                       int moveOrientation, int projectileSpeed)
            : base(health, entitySpeed, cooldown, moveOrientation)
        {
            _speed = projectileSpeed;
        }

        public abstract void Update();
        public abstract bool IsOutOfBounds();
        public abstract bool IntersectsWith(Entity entity);
    }
}
